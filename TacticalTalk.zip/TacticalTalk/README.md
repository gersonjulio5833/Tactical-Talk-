# TacticalTalk 3.0 — rádio em ecrã completo + Bluetooth + ligação híbrida (sem Internet)

**Estado real: código gerado; NÃO compilado aqui e NÃO testado em telemóveis.** A primeira compilação é a do
GitHub Actions. Nada abaixo deve ser dado como funcional até ser testado em aparelhos reais.

## Arquitectura
- `CommCore` (objecto do processo): dono das ligações, áudio, canais, cifra, retransmissão, reconexão.
- `CommService` (serviço em primeiro plano + notificação): mantém o processo vivo com o ecrã bloqueado ou a interface fechada.
- `MainActivity`: só mostra o estado (4 separadores: Início, Dispositivos, Canais, Mais).
- `BootReceiver`: retoma após reiniciar (se Arranque automático estiver activo e não se tiver carregado em PARAR SERVIÇO).
- Ligação: Wi-Fi Direct (convites do sistema) **ou** modo hotspot (um telemóvel cria a sala, os outros entram no Wi-Fi dele).

## Funcionalidades
- Walkie-Talkie (premir e falar) e Chamada ao Vivo (duplex; eco/ruído reduzidos quando o aparelho suporta; ideal entre 2 aparelhos).
- URGÊNCIA (manter premido): alerta sonoro distinto, banner e vibração; interrompe a recepção; quem estava a transmitir é avisado.
- Canais 01–08 com código: AES-128-GCM por pacote (chave PBKDF2). Sem o código não se ouve nem se entra (HELLO inválido → ligação recusada).
- Repetidor em estrela: no modo hotspot o anfitrião aceita vários clientes e retransmite entre eles (TTL, deduplicação, só pacotes autenticados).
- Vibração curta única por transmissão; "pim-pim" antes da voz; volume; PARAR SERVIÇO; reconexão automática (hotspot, 12 tentativas).

## Limitações (por resolver / sem garantia)
- Cadeias A→B→C→D (vários saltos): exigem que um telemóvel seja cliente e hotspot ao mesmo tempo; poucos aparelhos suportam. Não implementado. Alcance: não medido; sem promessas.
- Wi-Fi Direct: os convites do sistema falharam nos aparelhos de teste; por isso o modo hotspot existe.
- Retoma após reinício: só em modo hotspot (anfitrião/cliente); Wi-Fi Direct exige abrir a app. O telefone tem de estar desbloqueado.
- Mais de 2 pessoas a falar ao mesmo tempo na Chamada ao Vivo: sem misturador, o áudio não é fiável.
- Poupança de bateria agressiva (ZTE, Xiaomi, etc.) pode matar o serviço. Sem protecção contra repetição de pacotes antigos capturados (fora da janela de duplicados).
- Opus não usado (PCM 16 kHz, ~256 kbit/s). Sem Wi-Fi Aware nem Bluetooth.

## Testes
Automáticos (GitHub Actions, `CoreTest`): cifra ida/volta, código errado, cabeçalho adulterado, duplicados.
Físicos (a fazer): ver a lista enviada no chat.

## Versão 3.0
- Interface: rádio desenhado em código (RadioView), ecrã completo imersivo; as áreas de toque são os rectângulos desenhados. LCD com dados reais (CommCore).
- Botões: 0–9 (canal no início / opção n nos menus / código no ecrã de código), setas, MENU (abrir/escolher), voltar, verde (ligar com o último método ou iniciar chamada), vermelho (terminar), PTT (lateral esquerdo), URGÊNCIA (lateral direito), botão rotativo = volume da voz.
- Sons: tecla, confirmação, "tim-tim" de início, fim, erro (AudioTrack próprio; não usam a fila da voz).
- Bluetooth Classic (RFCOMM): mesmo protocolo e cifra. Emparelhar nas definições do Android; escolher o dispositivo na lista.
- Camada híbrida: um vizinho pode ter várias ligações (Wi-Fi Direct, hotspot, Bluetooth). O áudio segue por UMA (a de melhor pontuação medida: RTT, jitter, pings perdidos, áudio descartado, falhas recentes) com histerese; as outras ficam em espera. Método Automático/Bluetooth/Wi-Fi Direct/Hotspot nas definições.
- Limitações: não há prova de que os transportes funcionam em simultâneo em cada telemóvel; Bluetooth e retoma automática por Wi-Fi Direct não testados; a fotografia de referência não é usada como imagem (o rádio é desenhado, sem a marca do fabricante).

## Versão 3.1 (correcções e melhorias)
- Ícone de voltar redesenhado (seta curva de retorno, centrada). Botões laterais PTT/URGÊNCIA maiores (0,105 W) sem tocar no LCD (que começa em 0,13 W).
- LCD maior (até 50% da zona superior). Listas com deslocamento suave, barra lateral e destaque sempre visível: os 8 canais são acessíveis com setas, deslize, toque ou teclas 1-8.
- Visor interactivo: teclas desenhadas e toques no LCD chamam as MESMAS funções do RadioController (sem estado duplicado).
- Hora do Android (fuso e 12/24 h; recarrega ao mudar o fuso), bateria real com estado de carga (BroadcastReceiver), rede móvel real (PhoneNet): tipo 2G/3G/4G/5G só com permissão READ_PHONE_STATE opcional; frequência "indisponível".
- Canais: nome e palavra-passe POR canal (Prefs name_N / code_N); gestão: usar, editar nome, definir/alterar/remover palavra-passe (com confirmação), repor nome. Migração do código único antigo.
- Editor de texto multitoque (TextEditor, testado) + teclado Android como alternativa.
- Vibração: eventos TOUCH (início de PTT) e ALARM (recepção/urgência), uma vez por transmissão; "Testar vibração" mostra o diagnóstico (sem vibrador, falha, etc.).
- Por verificar em aparelho real: toda a comunicação, vibração, Bluetooth, tipo de rede móvel, retoma após reinício.
