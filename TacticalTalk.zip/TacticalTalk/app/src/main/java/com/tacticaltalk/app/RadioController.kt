package com.tacticaltalk.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import java.util.TimeZone

enum class Key(val digit: Int = -1) {
    N0(0), N1(1), N2(2), N3(3), N4(4), N5(5), N6(6), N7(7), N8(8), N9(9),
    STAR, HASH, MENU, BACK, GREEN, RED, UP, DOWN
}

class Item(val title: String, val sub: String = "", val value: String = "", val checked: Boolean? = null, val action: () -> Unit)

class MenuDef(private val titleFn: () -> String, val items: () -> List<Item>) {
    constructor(t: String, items: () -> List<Item>) : this({ t }, items)

    val title: String get() = titleFn()
}

/** Edição de texto no LCD (nomes e palavras-passe). */
class EditState(val title: String, val ed: TextEditor, val secret: Boolean, val minLen: Int, val onSave: (String) -> Unit)

/**
 * Lógica ÚNICA do rádio. Teclas desenhadas e toques no LCD chamam as mesmas funções (press, tapRow, moveSel...),
 * por isso nunca ficam dessincronizados. Nada aqui simula ligações: tudo lê/comanda o CommCore.
 */
class RadioController(private val ctx: Context, private val host: Host) {

    interface Host {
        /** kind 0 = microfone + dispositivos próximos/localização; 1 = Bluetooth; 2 = estado do telefone (tipo de rede móvel). */
        fun needPermissions(kind: Int, then: () -> Unit)

        /** Teclado normal do Android (alternativa ao teclado do rádio). */
        fun askText(title: String, initial: String, max: Int, secret: Boolean, onResult: (String?) -> Unit)
    }

    private val handler = Handler(Looper.getMainLooper())

    var menu: MenuDef? = null
    private val stack = ArrayList<MenuDef>()
    var sel = 0
    var infoPage = 0 // 0 início, 1 sinal, 2 estado geral
    var edit: EditState? = null
    var toast: String? = null
    private var toastUntil = 0L
    @Volatile var pttHeld = false
    @Volatile var sosHeld = false

    // ---------- bateria e hora REAIS do Android ----------
    @Volatile var batteryPct = 0; private set
    @Volatile var charging = false; private set
    private var attached = false

    private val sysReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_BATTERY_CHANGED -> readBattery(i)
                Intent.ACTION_TIMEZONE_CHANGED -> TimeZone.setDefault(null) // volta a ler o fuso do Android
            }
        }
    }

    private fun readBattery(i: Intent?) {
        if (i == null) return
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (lvl >= 0 && sc > 0) batteryPct = lvl * 100 / sc
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    }

    fun attach() {
        if (attached) return
        attached = true
        val f = IntentFilter()
        f.addAction(Intent.ACTION_BATTERY_CHANGED)
        f.addAction(Intent.ACTION_TIMEZONE_CHANGED)
        readBattery(ContextCompat.registerReceiver(ctx, sysReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED))
        TimeZone.setDefault(null)
    }

    fun detach() {
        if (!attached) return
        attached = false
        try {
            ctx.unregisterReceiver(sysReceiver)
        } catch (_: Exception) {
        }
    }

    // ---------- utilitários ----------

    private fun snd(s: UiSounds.S) = UiSounds.play(ctx, s)

    fun say(t: String) {
        toast = t
        toastUntil = SystemClock.elapsedRealtime() + 2500
    }

    fun currentToast(): String? {
        if (toast != null && SystemClock.elapsedRealtime() > toastUntil) toast = null
        return toast
    }

    private fun goHome() {
        menu = null
        stack.clear()
        sel = 0
        infoPage = 0
    }

    private fun open(m: MenuDef) {
        menu?.let { stack.add(it) }
        menu = m
        sel = 0
    }

    fun volumeNorm(): Float = Prefs.voiceVolume(ctx) / 100f

    fun setVolumeNorm(v: Float) {
        CommCore.setVolume(v.coerceIn(0f, 1f))
    }

    // ---------- teclas (física desenhada) ----------

    fun press(k: Key) {
        snd(UiSounds.S.KEY)
        val e = edit
        if (e != null) {
            editKey(k, e)
            return
        }
        if (k.digit >= 0) {
            digit(k.digit)
            return
        }
        when (k) {
            Key.UP -> move(-1)
            Key.DOWN -> move(1)
            Key.MENU -> menuKey()
            Key.BACK -> back()
            Key.GREEN -> green()
            Key.RED -> red()
            Key.HASH -> if (menu != null) {
                activate()
            } else {
                infoPage = (infoPage + 1) % 3
            }
            Key.STAR -> if (menu != null) back() else snd(UiSounds.S.ERROR)
            else -> {}
        }
    }

    private fun digit(d: Int) {
        val m = menu
        if (m != null) {
            val items = m.items()
            val idx = d - 1
            if (idx in items.indices) {
                sel = idx
                activate()
            } else snd(UiSounds.S.ERROR)
        } else if (d in 1..8) {
            CommCore.selectChannel(d)
            say(Prefs.channelLabel(ctx, d))
            snd(UiSounds.S.OK)
        } else {
            say("Canais 1 a 8")
            snd(UiSounds.S.ERROR)
        }
    }

    /** Seta cima/baixo OU deslize no LCD: move o destaque (o LCD acompanha com deslocamento). */
    fun move(dir: Int) {
        val m = menu
        if (m != null) {
            val n = m.items().size
            if (n > 0) sel = (sel + dir).coerceIn(0, n - 1)
        } else infoPage = (infoPage + dir + 3) % 3
    }

    fun moveSel(dir: Int) = move(dir)

    private fun menuKey() {
        val m = menu
        if (m == null) {
            open(mainMenu)
            snd(UiSounds.S.OK)
        } else activate()
    }

    private fun activate() {
        val m = menu ?: return
        val items = m.items()
        if (sel in items.indices) {
            snd(UiSounds.S.OK)
            items[sel].action()
        } else snd(UiSounds.S.ERROR)
    }

    private fun back() {
        if (stack.isNotEmpty()) {
            menu = stack.removeAt(stack.size - 1)
            sel = 0
        } else if (menu != null) {
            menu = null
            sel = 0
        } else if (infoPage != 0) infoPage = 0 else snd(UiSounds.S.ERROR)
    }

    private fun green() {
        if (CommCore.connected()) {
            if (!CommCore.quickConnect()) {
                say("Já ligado")
                snd(UiSounds.S.ERROR)
            } else snd(UiSounds.S.OK)
            return
        }
        host.needPermissions(0) {
            if (CommCore.quickConnect()) {
                snd(UiSounds.S.OK)
                say("A ligar…")
            } else {
                open(devicesMenu)
                say("Escolha um dispositivo")
            }
        }
    }

    private fun red() {
        when {
            CommCore.callActive -> CommCore.endCall()
            CommCore.transmitting() -> CommCore.stopTransmit()
            CommCore.state != CommCore.St.IDLE || CommCore.reconnecting -> {
                CommCore.stopAll(true)
                goHome()
                say("Sessão terminada")
            }
            else -> snd(UiSounds.S.ERROR)
        }
        snd(UiSounds.S.TX_END)
    }

    // ---------- toques no LCD (interface digital: MESMA lógica) ----------

    fun tapRow(idx: Int) {
        val m = menu ?: return
        val items = m.items()
        if (idx in items.indices) {
            sel = idx
            activate()
        } else snd(UiSounds.S.ERROR)
    }

    fun tapBack() {
        snd(UiSounds.S.KEY)
        back()
    }

    /** Barra de estado: 0 = rede/ligação (sinal), 1 = participantes (grupos), 2 = bateria/estado geral. */
    fun tapStatus(zone: Int) {
        snd(UiSounds.S.KEY)
        when (zone) {
            0 -> {
                goHome()
                infoPage = 1
            }
            1 -> {
                goHome()
                open(groupsMenu)
            }
            else -> {
                goHome()
                infoPage = 2
            }
        }
    }

    fun tapCard() {
        if (menu != null || edit != null || infoPage != 0) return
        snd(UiSounds.S.OK)
        open(channelsMenu)
    }

    /** Teclas do LCD no início: 0 Grupos, 1 Canais, 2 Definições. */
    fun soft(i: Int) {
        if (menu != null || edit != null || infoPage != 0) return
        snd(UiSounds.S.OK)
        when (i) {
            0 -> open(groupsMenu)
            1 -> open(channelsMenu)
            else -> open(settingsMenu)
        }
    }

    // ---------- PTT e URGÊNCIA (botões laterais) ----------

    fun sideDown(urgent: Boolean) {
        if (!CommCore.connected()) {
            say("Sem ligação: ligue primeiro")
            snd(UiSounds.S.ERROR)
            return
        }
        if (CommCore.mode == CommCore.Mode.CALL && !urgent) {
            say("Chamada: use o botão verde")
            snd(UiSounds.S.ERROR)
            return
        }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            host.needPermissions(0) { }
            return
        }
        if (pttHeld || sosHeld) return
        if (urgent) sosHeld = true else pttHeld = true
        snd(UiSounds.S.TX_START)
        handler.postDelayed({
            if ((urgent && sosHeld) || (!urgent && pttHeld)) CommCore.pttDown(urgent)
        }, 170)
    }

    fun sideUp(urgent: Boolean) {
        val was = if (urgent) sosHeld else pttHeld
        if (urgent) sosHeld = false else pttHeld = false
        if (!was) return
        val tx = CommCore.transmitting()
        CommCore.pttUp()
        if (tx) snd(UiSounds.S.TX_END)
    }

    // ---------- editor de texto (teclado do rádio ou do Android) ----------

    private fun startEdit(title: String, initial: String, max: Int, secret: Boolean, minLen: Int, onSave: (String) -> Unit) {
        if (Prefs.textMode(ctx) == "android") {
            host.askText(title, initial, max, secret) { r -> if (r != null) finishEdit(r.trim().take(max), minLen, onSave) }
        } else {
            edit = EditState(title, TextEditor(initial, max, autoCap = !secret), secret, minLen, onSave)
        }
    }

    private fun finishEdit(t: String, minLen: Int, onSave: (String) -> Unit): Boolean {
        if (t.length < minLen) {
            say(if (t.isEmpty()) "Texto vazio" else "Mínimo de $minLen caracteres")
            snd(UiSounds.S.ERROR)
            return false
        }
        onSave(t)
        snd(UiSounds.S.OK)
        return true
    }

    private fun editKey(k: Key, e: EditState) {
        when {
            k.digit >= 0 -> if (!e.ed.tap(k.digit, SystemClock.elapsedRealtime())) {
                say("Limite de " + e.ed.max + " caracteres")
                snd(UiSounds.S.ERROR)
            }
            k == Key.STAR -> e.ed.backspace()
            k == Key.HASH -> e.ed.clear()
            k == Key.UP -> e.ed.toggleCase()
            k == Key.MENU || k == Key.GREEN -> editSave()
            k == Key.BACK || k == Key.RED -> editCancel()
            else -> {}
        }
    }

    fun editSave() {
        val e = edit ?: return
        e.ed.commit()
        if (finishEdit(e.ed.result(), e.minLen, e.onSave)) edit = null
    }

    fun editCancel() {
        if (edit != null) {
            edit = null
            say("Cancelado")
            snd(UiSounds.S.KEY)
        }
    }

    fun editAndroid() {
        val e = edit ?: return
        edit = null
        host.askText(e.title, e.ed.result(), e.ed.max, e.secret) { r ->
            if (r != null) finishEdit(r.trim().take(e.ed.max), e.minLen, e.onSave)
        }
    }

    // ---------- menus reais ----------

    private var manageCh = 1
    private var confTitle = ""
    private var confSub = ""
    private var confYes: () -> Unit = {}

    private fun confirm(title: String, sub: String, yes: () -> Unit) {
        confTitle = title
        confSub = sub
        confYes = yes
        open(confirmMenu)
    }

    private fun toggle(title: String, get: () -> Boolean, set: (Boolean) -> Unit, after: () -> Unit = {}): Item =
        Item(title, value = if (get()) "ON" else "OFF", checked = get()) {
            set(!get())
            after()
        }

    private fun methodLabel(): String = when (Prefs.method(ctx)) {
        "bt" -> "Bluetooth"
        "p2p" -> "Wi-Fi Direct"
        "lan" -> "Hotspot"
        else -> "Automático"
    }

    private val mainMenu: MenuDef = MenuDef("Menu") {
        listOf(
            Item("Dispositivos", "Procurar e ligar") { open(devicesMenu) },
            Item("Canais", Prefs.channelLabel(ctx, CommCore.channelNumber)) { open(channelsMenu) },
            Item("Grupos", "Participantes ligados") { open(groupsMenu) },
            Item("Modo", value = if (CommCore.mode == CommCore.Mode.WALKIE) "Walkie" else "Chamada") {
                CommCore.setMode(if (CommCore.mode == CommCore.Mode.WALKIE) CommCore.Mode.CALL else CommCore.Mode.WALKIE)
            },
            Item("Método de ligação", value = methodLabel()) { open(linkMenu) },
            Item("Definições") { open(settingsMenu) },
            Item("Sinal e ligações") {
                goHome()
                infoPage = 1
            },
            Item("Parar serviço", "Termina tudo (pede confirmação)") {
                confirm("Parar o serviço?", "Termina ligações, áudio e a retoma automática") {
                    CommCore.stopAll(true)
                    goHome()
                }
            }
        )
    }

    private val confirmMenu: MenuDef = MenuDef({ confTitle }) {
        listOf(
            Item("Cancelar", confSub) { back() },
            Item("Sim, confirmar") {
                val y = confYes
                back()
                y()
            }
        )
    }

    private val devicesMenu: MenuDef = MenuDef("Dispositivos") {
        val l = ArrayList<Item>()
        l.add(Item("Wi-Fi Direct", "Procurar dispositivos") {
            host.needPermissions(0) {
                if (CommCore.searchBlockedReason() != null) {
                    say("Ligue a Localização")
                    snd(UiSounds.S.ERROR)
                } else CommCore.startSearch()
            }
        })
        l.add(Item("Hotspot: criar sala", "Este é o hotspot") {
            host.needPermissions(0) {
                CommCore.startHost()
                goHome()
            }
        })
        l.add(Item("Hotspot: entrar", "Wi-Fi no hotspot do outro") {
            host.needPermissions(0) {
                CommCore.startJoin()
                goHome()
            }
        })
        l.add(Item("Bluetooth", "Emparelhados e próximos") {
            host.needPermissions(1) { CommCore.startBluetooth() }
        })
        for (e in CommCore.deviceEntries()) {
            l.add(Item(e.label, e.sub) {
                host.needPermissions(if (e.transport == Transport.BLUETOOTH) 1 else 0) {
                    CommCore.connectEntry(e)
                    goHome()
                }
            })
        }
        l
    }

    /** Lista dos 8 canais: OK abre a gestão do canal destacado. */
    private val channelsMenu: MenuDef = MenuDef("Canais") {
        (1..8).map { n ->
            Item(
                Prefs.channelLabel(ctx, n),
                if (CommCore.channelProtected(n)) "Protegido por palavra-passe" else "Sem protecção",
                checked = n == CommCore.channelNumber
            ) {
                manageCh = n
                open(manageMenu)
            }
        }
    }

    private val manageMenu: MenuDef = MenuDef({ "Gestão: " + Prefs.channelLabel(ctx, manageCh) }) {
        val n = manageCh
        val prot = CommCore.channelProtected(n)
        val l = ArrayList<Item>()
        l.add(Item("Usar este canal", if (n == CommCore.channelNumber) "Canal activo" else "", checked = n == CommCore.channelNumber) {
            CommCore.selectChannel(n)
            say(Prefs.channelLabel(ctx, n))
            goHome()
        })
        l.add(Item("Editar nome", Prefs.channelName(ctx, n)) {
            startEdit("Nome do canal $n", Prefs.channelName(ctx, n), 16, false, 1) {
                Prefs.setChannelName(ctx, n, it)
                CommCore.selectChannelRefresh()
                say("Nome guardado")
            }
        })
        l.add(Item("Estado", if (prot) "Protegido por palavra-passe" else "Sem palavra-passe", value = if (prot) "PROT." else "LIVRE", checked = prot) {
            say(if (prot) "Canal protegido" else "Canal sem protecção")
        })
        l.add(Item(if (prot) "Alterar palavra-passe" else "Definir palavra-passe", "4 a 12 caracteres") {
            startEdit("Palavra-passe do canal $n", "", 12, true, 4) {
                CommCore.setChannelCode(n, it)
                say("Palavra-passe guardada")
            }
        })
        if (prot) l.add(Item("Remover palavra-passe", "Pede confirmação") {
            confirm("Remover palavra-passe?", Prefs.channelLabel(ctx, n) + " fica sem protecção") {
                CommCore.setChannelCode(n, "")
                say("Palavra-passe removida")
            }
        })
        l.add(Item("Repor nome predefinido", Prefs.DEFAULT_NAMES[n - 1]) {
            Prefs.resetChannelName(ctx, n)
            CommCore.selectChannelRefresh()
            say("Nome reposto")
        })
        l
    }

    private val groupsMenu: MenuDef = MenuDef("Grupos") {
        if (CommCore.participants.isEmpty()) listOf(Item("Sem participantes", "Ligue-se a outro dispositivo") { })
        else CommCore.participants.values.map { n -> Item(n, Prefs.channelLabel(ctx, CommCore.channelNumber)) { } }
    }

    private val linkMenu: MenuDef = MenuDef("Método de ligação") {
        fun opt(title: String, sub: String, v: String) =
            Item(title, sub, checked = Prefs.method(ctx) == v) { Prefs.setMethod(ctx, v) }
        listOf(
            opt("Automático", "Escolhe pela qualidade medida", "auto"),
            opt("Bluetooth", "Preferir Bluetooth", "bt"),
            opt("Wi-Fi Direct", "Preferir Wi-Fi Direct", "p2p"),
            opt("Hotspot / rede local", "Preferir hotspot", "lan")
        )
    }

    private val settingsMenu: MenuDef = MenuDef("Definições") {
        listOf(
            Item("Volume da voz", value = Prefs.voiceVolume(ctx).toString() + "%") {
                setVolumeNorm(((Prefs.voiceVolume(ctx) / 25 + 1) % 5 * 25) / 100f)
            },
            Item("Volume dos sons", value = Prefs.uiVolume(ctx).toString() + "%") {
                Prefs.setUiVolume(ctx, ((Prefs.uiVolume(ctx) / 25 + 1) % 5) * 25)
            },
            toggle("Sons do rádio", { Prefs.radioSounds(ctx) }, { Prefs.setRadioSounds(ctx, it) }),
            toggle("Sinal pim-pim", { Prefs.beep(ctx) }, { Prefs.setBeep(ctx, it) }),
            toggle("Vibração de alertas", { Prefs.vibration(ctx) }, { Prefs.setVibration(ctx, it) }),
            Item("Testar vibração", "Envia uma vibração agora") { say(CommCore.testVibration()) },
            toggle("Segundo plano", { Prefs.background(ctx) }, { Prefs.setBackground(ctx, it) }, { CommCore.refreshService() }),
            toggle("Arranque automático", { Prefs.autostart(ctx) }, { Prefs.setAutostart(ctx, it) }),
            toggle("Reconexão automática", { Prefs.reconnect(ctx) }, { Prefs.setReconnect(ctx, it) }),
            toggle("Modo repetidor", { Prefs.relay(ctx) }, { Prefs.setRelay(ctx, it) }),
            Item("Escrever texto com", "Teclado do rádio ou do Android", if (Prefs.textMode(ctx) == "android") "Android" else "Rádio") {
                Prefs.setTextMode(ctx, if (Prefs.textMode(ctx) == "android") "radio" else "android")
            },
            Item("Tipo de rede móvel", "4G/5G (pede permissão do telefone)", if (Prefs.mobileInfo(ctx)) "ON" else "OFF", Prefs.mobileInfo(ctx)) {
                if (Prefs.mobileInfo(ctx)) {
                    Prefs.setMobileInfo(ctx, false)
                    PhoneNet.refresh()
                } else host.needPermissions(2) {
                    Prefs.setMobileInfo(ctx, true)
                    PhoneNet.refresh()
                    say("Tipo de rede activado")
                }
            }
        )
    }
}
