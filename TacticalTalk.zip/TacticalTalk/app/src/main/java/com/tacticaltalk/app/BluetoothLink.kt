package com.tacticaltalk.app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import java.util.UUID

/**
 * Transporte Bluetooth Classic (RFCOMM). Foi escolhido em vez de BLE porque o áudio contínuo
 * (~35 kB/s com cabeçalhos) excede a largura de banda prática do BLE. RFCOMM é um fluxo fiável
 * bidireccional, por isso reutiliza o mesmo protocolo (PeerConnection) dos outros transportes.
 * Ligação "insegura" = sem emparelhamento obrigatório; a confidencialidade vem da cifra por canal da app.
 */
@SuppressLint("MissingPermission")
class BluetoothLink(private val ctx: Context, private val l: Listener) {

    interface Listener {
        fun onBtSocket(s: BluetoothSocket, incoming: Boolean)
        fun onBtConnectFailed(msg: String)
        fun onBtDevices(list: List<BtDev>)
    }

    class BtDev(val name: String, val address: String, val paired: Boolean)

    companion object {
        val APP_UUID: UUID = UUID.fromString("7f3c0a52-5b1e-4f4b-9c1e-5a7d2c8b9e11")
    }

    private val adapter: BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    private val handler = Handler(Looper.getMainLooper())
    private var server: BluetoothServerSocket? = null
    @Volatile private var serverRunning = false
    private var receiverOn = false
    private val found = LinkedHashMap<String, BtDev>()

    val supported: Boolean get() = adapter != null && ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH)
    val enabled: Boolean get() = adapter?.isEnabled == true
    val serverActive: Boolean get() = serverRunning

    private fun granted(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    /** Permissão necessária para ligar/aceitar. */
    fun permitted(): Boolean = Build.VERSION.SDK_INT < 31 || granted(Manifest.permission.BLUETOOTH_CONNECT)

    /** Permissão necessária para procurar dispositivos novos. */
    fun scanPermitted(): Boolean =
        if (Build.VERSION.SDK_INT >= 31) granted(Manifest.permission.BLUETOOTH_SCAN) && granted(Manifest.permission.BLUETOOTH_CONNECT)
        else granted(Manifest.permission.ACCESS_FINE_LOCATION)

    fun startServer() {
        val ad = adapter ?: return
        if (serverRunning || !ad.isEnabled || !permitted()) return
        serverRunning = true
        Thread({
            var ss: BluetoothServerSocket? = null
            try {
                ss = ad.listenUsingInsecureRfcommWithServiceRecord("TacticalTalk", APP_UUID)
                server = ss
                while (true) {
                    val s = ss.accept()
                    handler.post { l.onBtSocket(s, true) }
                }
            } catch (e: Exception) {
                // fechado de propósito ou falha: termina a escuta
            } finally {
                serverRunning = false
                try {
                    ss?.close()
                } catch (_: Exception) {
                }
            }
        }, "bt-server").start()
    }

    fun stopServer() {
        try {
            server?.close()
        } catch (_: Exception) {
        }
        server = null
    }

    fun connect(address: String) {
        val ad = adapter ?: return
        if (!ad.isEnabled || !permitted()) {
            handler.post { l.onBtConnectFailed("Bluetooth desligado ou sem permissão") }
            return
        }
        Thread({
            var s: BluetoothSocket? = null
            try {
                try {
                    ad.cancelDiscovery()
                } catch (_: Exception) {
                }
                val sock = ad.getRemoteDevice(address).createInsecureRfcommSocketToServiceRecord(APP_UUID)
                s = sock
                sock.connect()
                handler.post { l.onBtSocket(sock, false) }
            } catch (e: Exception) {
                try {
                    s?.close()
                } catch (_: Exception) {
                }
                val msg = e.message ?: "falha"
                handler.post { l.onBtConnectFailed(msg) }
            }
        }, "bt-connect").start()
    }

    fun refreshBonded() {
        val ad = adapter ?: return
        if (!permitted()) return
        try {
            for (d in ad.bondedDevices ?: emptySet<BluetoothDevice>()) {
                found[d.address] = BtDev(d.name ?: d.address, d.address, true)
            }
        } catch (_: Exception) {
        }
        push()
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == BluetoothDevice.ACTION_FOUND) {
                val d = device(i) ?: return
                if (!found.containsKey(d.address) || found[d.address]?.paired != true) {
                    found[d.address] = BtDev(d.name ?: d.address, d.address, d.bondState == BluetoothDevice.BOND_BONDED)
                    push()
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun device(i: Intent): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        else i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)

    private fun push() {
        l.onBtDevices(found.values.sortedByDescending { it.paired })
    }

    fun startDiscovery() {
        val ad = adapter ?: return
        if (!ad.isEnabled || !scanPermitted()) return
        if (!receiverOn) {
            ContextCompat.registerReceiver(ctx, receiver, IntentFilter(BluetoothDevice.ACTION_FOUND), ContextCompat.RECEIVER_NOT_EXPORTED)
            receiverOn = true
        }
        try {
            if (ad.isDiscovering) ad.cancelDiscovery()
            ad.startDiscovery()
        } catch (_: Exception) {
        }
    }

    fun release() {
        stopServer()
        try {
            adapter?.cancelDiscovery()
        } catch (_: Exception) {
        }
        if (receiverOn) {
            try {
                ctx.unregisterReceiver(receiver)
            } catch (_: Exception) {
            }
            receiverOn = false
        }
    }
}
