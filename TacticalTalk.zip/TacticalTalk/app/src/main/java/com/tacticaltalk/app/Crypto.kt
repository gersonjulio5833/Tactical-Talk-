package com.tacticaltalk.app

import java.nio.ByteBuffer
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Cifra por canal: chave AES-128 derivada do código do canal (PBKDF2-HMAC-SHA256) e AES-GCM
 * em cada pacote. Quem não tem o código não consegue produzir pacotes válidos nem ouvir o áudio.
 * Limitação: sem protecção contra repetição de pacotes capturados fora da janela de duplicados.
 */
object Crypto {
    private val rnd = SecureRandom()

    fun deriveKey(code: String, channel: Int): SecretKeySpec? {
        if (code.isEmpty()) return null
        val spec = PBEKeySpec(code.toCharArray(), ("TacticalTalk-v2-ch$channel").toByteArray(), 20000, 128)
        val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return SecretKeySpec(raw, "AES")
    }

    /** Dados autenticados (não cifrados): tipo, canal, origem, txId, seq. O TTL fica de fora para os repetidores o poderem alterar. */
    fun aad(type: Int, channel: Int, src: Int, tx: Int, seq: Int): ByteArray =
        ByteBuffer.allocate(14).put(type.toByte()).put(channel.toByte()).putInt(src).putInt(tx).putInt(seq).array()

    fun seal(key: SecretKeySpec, plain: ByteArray, aad: ByteArray): ByteArray {
        val iv = ByteArray(12)
        rnd.nextBytes(iv)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        c.updateAAD(aad)
        return iv + c.doFinal(plain)
    }

    fun open(key: SecretKeySpec, data: ByteArray, aad: ByteArray): ByteArray? {
        if (data.size < 28) return null
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, data.copyOfRange(0, 12)))
            c.updateAAD(aad)
            c.doFinal(data, 12, data.size - 12)
        } catch (e: Exception) {
            null
        }
    }
}
