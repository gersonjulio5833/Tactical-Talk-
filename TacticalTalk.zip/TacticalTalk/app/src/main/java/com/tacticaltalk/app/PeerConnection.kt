package com.tacticaltalk.app

import android.os.SystemClock
import java.io.BufferedInputStream
import java.io.Closeable
import java.io.InputStream
import java.io.OutputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicInteger

/**
 * Ligação a um vizinho por qualquer transporte (TCP em Wi-Fi Direct/hotspot, RFCOMM em Bluetooth).
 * Leitura numa thread; escrita numa fila de uma thread. Guarda métricas reais da ligação.
 */
class PeerConnection(
    private val closeable: Closeable,
    inStream: InputStream,
    outStream: OutputStream,
    val transport: Transport,
    private val listener: Listener
) {
    constructor(socket: Socket, transport: Transport, listener: Listener) :
        this(socket, socket.getInputStream(), socket.getOutputStream(), transport, listener)

    interface Listener {
        fun onPacket(from: PeerConnection, p: Packet)
        fun onClosed(from: PeerConnection, reason: String)
    }

    private val out = DataOutputStream(BufferedOutputStream(outStream, 4096))
    private val input = DataInputStream(BufferedInputStream(inStream, 4096))
    private val sender = Executors.newSingleThreadExecutor { r -> Thread(r, "peer-writer") }
    private val pending = AtomicInteger(0)
    @Volatile private var closed = false

    val created: Long = SystemClock.elapsedRealtime()
    @Volatile var lastRx: Long = created
    @Volatile var authorized = false

    // ----- identificação e métricas (medições reais) -----
    @Volatile var peerId = 0
    @Volatile var rtt = -1.0          // ms, média móvel
    @Volatile var jitter = 0.0        // ms, média móvel de |Δrtt|
    @Volatile var lossEma = 0.0       // 0..1, pings sem resposta
    @Volatile var dropEma = 0.0       // 0..1, tramas de áudio descartadas por fila cheia
    @Volatile var missedStreak = 0
    @Volatile var pingOut = false
    @Volatile var dropped = 0
    @Volatile var lastDropped = 0
    val isClosed: Boolean get() = closed

    fun start() {
        Thread({ readLoop() }, "peer-reader").start()
    }

    private fun readLoop() {
        try {
            while (!closed) {
                if (input.readUnsignedShort() != Protocol.MAGIC) throw IOException("Pacote inválido")
                val type = input.readUnsignedByte()
                val ttl = input.readUnsignedByte()
                val flags = input.readUnsignedByte()
                val channel = input.readUnsignedByte()
                val src = input.readInt()
                val tx = input.readInt()
                val seq = input.readInt()
                val len = input.readUnsignedShort()
                if (len > Protocol.MAX_PAYLOAD) throw IOException("Pacote demasiado grande")
                val payload = ByteArray(len)
                input.readFully(payload)
                listener.onPacket(this, Packet(type, ttl, flags, channel, src, tx, seq, payload))
            }
        } catch (e: Exception) {
            close(e.message ?: "Ligação terminada", notify = true)
        }
    }

    private fun write(p: Packet) {
        synchronized(out) {
            out.writeShort(Protocol.MAGIC)
            out.writeByte(p.type)
            out.writeByte(p.ttl)
            out.writeByte(p.flags)
            out.writeByte(p.channel)
            out.writeInt(p.src)
            out.writeInt(p.tx)
            out.writeInt(p.seq)
            out.writeShort(p.payload.size)
            out.write(p.payload)
            out.flush()
        }
    }

    /** Envia sem bloquear quem chama. Áudio é descartado se a fila acumular (~1 s). */
    fun send(p: Packet) {
        if (closed) return
        if (p.type == Protocol.T_AUDIO && pending.get() > 50) {
            dropped++
            return
        }
        pending.incrementAndGet()
        try {
            sender.execute {
                try {
                    write(p)
                } catch (e: Exception) {
                    close(e.message ?: "Erro de escrita", notify = true)
                } finally {
                    pending.decrementAndGet()
                }
            }
        } catch (e: RejectedExecutionException) {
            pending.decrementAndGet()
        }
    }

    /** Desligar voluntariamente: envia o pacote de despedida e fecha, sem notificar o listener. */
    fun sendByeAndClose(bye: Packet) {
        if (closed) return
        try {
            sender.execute {
                try {
                    write(bye)
                } catch (_: Exception) {
                }
                try {
                    closeable.close()
                } catch (_: Exception) {
                }
            }
        } catch (_: RejectedExecutionException) {
        }
        closed = true
        sender.shutdown()
    }

    fun close(reason: String, notify: Boolean) {
        synchronized(this) {
            if (closed) return
            closed = true
        }
        try {
            closeable.close()
        } catch (_: Exception) {
        }
        sender.shutdownNow()
        if (notify) listener.onClosed(this, reason)
    }
}
