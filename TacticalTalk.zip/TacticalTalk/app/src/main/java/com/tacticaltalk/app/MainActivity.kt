package com.tacticaltalk.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.widget.EditText
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** Janela única: o rádio ocupa todo o ecrã (modo imersivo). A comunicação vive no CommCore, não aqui. */
class MainActivity : AppCompatActivity(), RadioController.Host {

    private lateinit var radio: RadioView
    private lateinit var controller: RadioController
    private var pendingAction: (() -> Unit)? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            if (res.values.all { it }) pendingAction?.invoke() else Toast.makeText(this, R.string.perm_denied, Toast.LENGTH_LONG).show()
            pendingAction = null
        }
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // ecrã completo: o conteúdo desenha-se por baixo das barras do sistema e da câmara
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        volumeControlStream = android.media.AudioManager.STREAM_MUSIC

        CommCore.init(this)
        controller = RadioController(this, this)
        radio = RadioView(this)
        radio.ctl = controller
        setContentView(radio)
        hideBars()

        if (Build.VERSION.SDK_INT >= 33 && Prefs.background(this) &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    /** As barras reaparecem temporariamente com o gesto do sistema e voltam a esconder-se sozinhas. */
    private fun hideBars() {
        val c = WindowInsetsControllerCompat(window, radio)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onResume() {
        super.onResume()
        controller.attach() // bateria, hora e fuso reais do Android
        CommCore.onChange = { radio.invalidate() }
        radio.invalidate()
    }

    override fun onPause() {
        controller.detach()
        super.onPause()
    }

    override fun onDestroy() {
        CommCore.onChange = null
        // Com "Segundo plano" desligado, sair da interface termina o serviço.
        if (isFinishing && !Prefs.background(this)) CommCore.stopAll(false)
        super.onDestroy()
    }

    // ---------- permissões ----------

    private fun need(kind: Int): List<String> {
        if (kind == 2) return listOf(Manifest.permission.READ_PHONE_STATE) // só para mostrar 4G/5G (opcional)
        val l = ArrayList<String>()
        l.add(Manifest.permission.RECORD_AUDIO)
        if (kind == 1) {
            if (Build.VERSION.SDK_INT >= 31) {
                l.add(Manifest.permission.BLUETOOTH_CONNECT)
                l.add(Manifest.permission.BLUETOOTH_SCAN)
            } else l.add(Manifest.permission.ACCESS_FINE_LOCATION)
        } else {
            if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            else l.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        return l
    }

    override fun needPermissions(kind: Int, then: () -> Unit) {
        val missing = need(kind).filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) {
            then()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.perm_title)
            .setMessage(if (kind == 1) R.string.perm_message_bt else if (kind == 2) R.string.perm_message_phone else R.string.perm_message)
            .setCancelable(false)
            .setPositiveButton(R.string.perm_continue) { _, _ ->
                pendingAction = then
                permLauncher.launch(missing.toTypedArray())
            }
            .show()
    }

    /** Teclado normal do Android, como alternativa ao teclado do rádio. */
    override fun askText(title: String, initial: String, max: Int, secret: Boolean, onResult: (String?) -> Unit) {
        val et = EditText(this)
        et.setText(initial)
        et.setSelection(et.text.length)
        et.filters = arrayOf(InputFilter.LengthFilter(max))
        et.inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(et)
            .setPositiveButton(R.string.btn_save) { _, _ -> onResult(et.text.toString()) }
            .setNegativeButton(R.string.btn_cancel) { _, _ -> onResult(null) }
            .setOnCancelListener { onResult(null) }
            .show()
    }
}
