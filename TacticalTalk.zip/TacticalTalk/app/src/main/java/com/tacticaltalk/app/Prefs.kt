package com.tacticaltalk.app

import android.content.Context
import kotlin.random.Random

/** Preferências guardadas só no telemóvel (SharedPreferences). */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("tt_prefs", Context.MODE_PRIVATE)

    val DEFAULT_NAMES = arrayOf("Supervisão", "Soldadura", "Segurança", "Emergência", "Livre 05", "Livre 06", "Livre 07", "Livre 08")

    /** Nome do canal (editável pelo utilizador; guardado localmente). */
    fun channelName(c: Context, n: Int): String {
        val i = (n - 1).coerceIn(0, 7)
        val v = sp(c).getString("name_" + (i + 1), null)
        return if (v.isNullOrBlank()) DEFAULT_NAMES[i] else v
    }

    fun setChannelName(c: Context, n: Int, name: String) = sp(c).edit().putString("name_$n", name.trim()).apply()
    fun resetChannelName(c: Context, n: Int) = sp(c).edit().remove("name_$n").apply()

    fun channelLabel(c: Context, n: Int): String = "Canal " + n.toString().padStart(2, '0') + " — " + channelName(c, n)

    /** Palavra-passe de UM canal ("" = sem protecção). */
    fun code(c: Context, n: Int): String = sp(c).getString("code_$n", "") ?: ""
    fun hasCode(c: Context, n: Int): Boolean = code(c, n).isNotEmpty()
    fun setCode(c: Context, n: Int, code: String) {
        val e = sp(c).edit()
        if (code.isEmpty()) e.remove("code_$n") else e.putString("code_$n", code)
        e.apply()
    }

    /** Versões antigas guardavam um único código: passa-o para o canal activo e apaga o antigo. */
    fun migrate(c: Context) {
        val legacy = sp(c).getString("code", "") ?: ""
        if (legacy.isNotEmpty()) {
            val n = channel(c)
            if (!hasCode(c, n)) setCode(c, n, legacy)
        }
        if (sp(c).contains("code")) sp(c).edit().remove("code").apply()
    }

    fun textMode(c: Context) = sp(c).getString("textMode", "radio") ?: "radio" // radio | android
    fun setTextMode(c: Context, v: String) = sp(c).edit().putString("textMode", v).apply()

    fun mobileInfo(c: Context) = sp(c).getBoolean("mobileInfo", false)
    fun setMobileInfo(c: Context, v: Boolean) = sp(c).edit().putBoolean("mobileInfo", v).apply()

    fun vibration(c: Context) = sp(c).getBoolean("vibration", true)
    fun setVibration(c: Context, v: Boolean) = sp(c).edit().putBoolean("vibration", v).apply()

    fun background(c: Context) = sp(c).getBoolean("background", true)
    fun setBackground(c: Context, v: Boolean) = sp(c).edit().putBoolean("background", v).apply()

    fun autostart(c: Context) = sp(c).getBoolean("autostart", false)
    fun setAutostart(c: Context, v: Boolean) = sp(c).edit().putBoolean("autostart", v).apply()

    fun reconnect(c: Context) = sp(c).getBoolean("reconnect", true)
    fun setReconnect(c: Context, v: Boolean) = sp(c).edit().putBoolean("reconnect", v).apply()

    fun relay(c: Context) = sp(c).getBoolean("relay", true)
    fun setRelay(c: Context, v: Boolean) = sp(c).edit().putBoolean("relay", v).apply()

    fun beep(c: Context) = sp(c).getBoolean("beep", true)
    fun setBeep(c: Context, v: Boolean) = sp(c).edit().putBoolean("beep", v).apply()

    fun channel(c: Context) = sp(c).getInt("channel", 1)
    fun setChannel(c: Context, n: Int) = sp(c).edit().putInt("channel", n.coerceIn(1, 8)).apply()

    /** true se o utilizador carregou em PARAR SERVIÇO (impede retoma automática). */
    fun stopped(c: Context) = sp(c).getBoolean("stopped", false)
    fun setStopped(c: Context, v: Boolean) = sp(c).edit().putBoolean("stopped", v).apply()

    fun lastMode(c: Context) = sp(c).getString("lastMode", "") ?: ""
    fun setLastMode(c: Context, v: String) = sp(c).edit().putString("lastMode", v).apply()

    fun radioSounds(c: Context) = sp(c).getBoolean("radioSounds", true)
    fun setRadioSounds(c: Context, v: Boolean) = sp(c).edit().putBoolean("radioSounds", v).apply()

    fun uiVolume(c: Context) = sp(c).getInt("uiVolume", 60)
    fun setUiVolume(c: Context, v: Int) = sp(c).edit().putInt("uiVolume", v.coerceIn(0, 100)).apply()

    fun voiceVolume(c: Context) = sp(c).getInt("voiceVolume", 80)
    fun setVoiceVolume(c: Context, v: Int) = sp(c).edit().putInt("voiceVolume", v.coerceIn(0, 100)).apply()

    /** auto | bt | p2p | lan */
    fun method(c: Context) = sp(c).getString("method", "auto") ?: "auto"
    fun setMethod(c: Context, v: String) = sp(c).edit().putString("method", v).apply()

    fun btAddress(c: Context) = sp(c).getString("btAddress", "") ?: ""
    fun btName(c: Context) = sp(c).getString("btName", "") ?: ""
    fun setBt(c: Context, address: String, name: String) = sp(c).edit().putString("btAddress", address).putString("btName", name).apply()

    fun nodeId(c: Context): Int {
        val s = sp(c)
        var id = s.getInt("nodeId", 0)
        if (id == 0) {
            id = Random.nextInt(1, Int.MAX_VALUE)
            s.edit().putInt("nodeId", id).apply()
        }
        return id
    }
}
